<nav class="navbar navbar-default navbar-top custom-navbar">
    <div class="top-blue-nav">
        <div class="container">
            <ul class="nav navbar-nav navbar-right m-none">
                <li><a class="p-tb-none" href="mailto:info@doggiedogworld.com" target="_top"><i class="m-r-xs fa fa-envelope-o" aria-hidden="true"></i>info@doggiedogworld.com</a></li>
                <li><a class="p-tb-none" href="javascript:void(0)"><i class="m-r-xs fa fa-phone" aria-hidden="true"></i>+91 22 2631 6691</a></li>
            </ul>
        </div>
    </div>
    <div class="bottom-navbar">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php"><img src="img/logo.png" class="img-responsive"></a>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="javascript:void(0)">About Us</a></li>
                    <li><a href="javascript:void(0)">Facilities</a></li>
                    <li><a href="javascript:void(0)">Client Talks</a></li>
                    <li><a href="javascript:void(0)">Blog</a></li>
                    <li><a href="javascript:void(0)">Contact Us</a></li>
                </ul>
            </div>
        </div>
    </div>
</nav>